{
"name": "AutoUpdater",
"version": "1.0.0.5",
"descriptions": "* Bug fixes and improvements.\r\n * Added Dark Theme.",
"downloadUrl": "https://github.com/M...utoUpdater.zip"
}
