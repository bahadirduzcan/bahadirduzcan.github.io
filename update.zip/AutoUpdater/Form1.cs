﻿using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace AutoUpdater
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private const string AppFileName = "AutoUpdater.zip";
		private const string UpdateUrl = "https://bahax41.github.io/api.js";

		private void ChangeStats(string stats)
		{
			label1.Invoke(new Action(() =>
			{
				label1.Text = stats;
			}));
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			//Get the current version
			var current = Assembly.GetExecutingAssembly().GetName().Version;
			lblVersion.Text = $"Current version: {current}";
			ChangeStats("");
		}


		private void btnCheckUpdate_Click(object sender, EventArgs e)
		{
			CheckUpdate();
		}


		#region Private Methods

		private void CheckUpdate()
		{
			ChangeStats("Checking updates...");

			//Get the current version
			var current = Assembly.GetExecutingAssembly().GetName().Version;
			using (var client = new WebClient())
			{
				var stream = client.OpenRead(UpdateUrl);

				if (stream != null)
				{
					using (var sr = new StreamReader(stream))
					{
						var result = sr.ReadToEnd();

						//Deserialize Object to ApplicationsInfo
						var app = JsonConvert.DeserializeObject<ApplicationInfo>(result);
						var version = Version.Parse(app.Version);
						var versionResult = version.CompareTo(current);

						//check for new version available
						if (versionResult > 0)
						{
							//Optional if you want to inform the user to download the update.
							var response = MessageBox.Show("There is a new version available, would you like to download it?\r\n" +
														   $"What's new?\r\n" +
														   $"Description:\r\n{app.Descriptions}\r\n\r\n" +
														   $"Version:{app.Version}"
								, "System Message", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
							if (response == DialogResult.Yes)
							{
								ChangeStats("Downloading update...");
								//Download the update
								DownloadUpdate(app.DownloadUrl);
							}
						}
						else
						{
							MessageBox.Show("Your are using the latest version.", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
							ChangeStats("");
						}
					}
				}
			}
		}

		private void DownloadUpdate(string downloadUrl)
		{

			var url = new Uri(downloadUrl);

			using (var client = new WebClient())
			{
				client.DownloadFileAsync(url, AppFileName);
				client.DownloadProgressChanged += ClientOnDownloadProgressChanged;
				client.DownloadFileCompleted += ClientOnDownloadFileCompleted;

			}
		}

		private void ClientOnDownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
		{
			if (e.Error != null)
			{
				MessageBox.Show(e.ToString());
				return;
			}

			var fileInfo = new FileInfo(AppFileName);

			var fileNameWithoutExt = fileInfo.Name.Replace(fileInfo.Extension, "");

			//	This will extract in the current directory->baseDir / Updates / FileNameWithoutExt->extracted files
			var outputDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Updates", fileNameWithoutExt);

			//Prevent UI threads locking
			Task.Run(async () =>
			{

				ChangeStats("Extracting file...");
				try
				{
					//TODO: Find better extractor tool

					if (Directory.Exists(outputDir))
					{
						Directory.Delete(outputDir, true);
					}

					//Extract the downloaded to the current directory
					//ZipFile.Extract working only in .zip  file
					ZipFile.ExtractToDirectory(AppFileName, outputDir);

					ChangeStats("File Extracted!");
					await Task.Delay(1000);

				}
				catch (Exception exception)
				{
					MessageBox.Show("The File is corrupted or: \r\n" + exception);
				}

			}).ContinueWith(_ =>
			{
				//Delete the downloaded file
				if (File.Exists(AppFileName))
				{
					File.Delete(AppFileName);
				}

				Invoke(new Action(() =>
				{
					ExecuteNewUpdate(outputDir);
				}));


			});

		}

		private void ClientOnDownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
		{
			var stats = string.Concat("Downloading ", e.ProgressPercentage, " %", "...");
			ChangeStats(stats);
			progressBar1.Value = e.ProgressPercentage;
		}

		private void ExecuteNewUpdate(string appPath)
		{

			var appDirectory = AppDomain.CurrentDomain.BaseDirectory;

			var updateSource = $"{appPath}";
			var updateDestination = $"{appDirectory}";

			//See more details in https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/xcopy

			string arg = $"/c timeout /t 2& xcopy {updateSource} {updateDestination} /y/c/q&  AutoUpdater.exe";

			var process = new Process();
			var startInfo = new ProcessStartInfo();
			startInfo.WorkingDirectory = updateDestination;
			startInfo.FileName = "cmd.exe";
			startInfo.Arguments = arg;

			////Display no windows
			startInfo.WindowStyle = ProcessWindowStyle.Hidden;
			startInfo.CreateNoWindow = true;

			process.StartInfo = startInfo;
			process.Start();

			Close();
		}

		#endregion


	}
}
